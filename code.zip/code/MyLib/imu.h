#ifndef _IMU_H
#define	_IMU_H
#include "board.h"

#define IMU_INTEGRAL_LIM  ( 2.0f *ANGLE_TO_RAD )

#define RtA 	  57.324841f

typedef struct _eulerAngle{
														float pitch;//float
														float roll;//float
														float yaw;//float
	                          long YAW;
	                          long Angle_error;
	                          long R__Angle;
	                          long last_Angle;
	                          int yaw_cnt;															
													}eulerAngle;


extern eulerAngle gimbalTopAngle;
extern eulerAngle gimbalBotAngle;

void TDT_IMUTopupdate(float half_T, vec3f* gyro, vec3f* acc);
void TDT_IMUBotupdate(float half_T, vec3f* gyro, vec3f* acc);

#endif

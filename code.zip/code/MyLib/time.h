#ifndef _TIME_H_
#define _TIME_H_

#include "board.h"

#define NOW 0
#define OLD 1
#define NEW 2

#define GET_TIME_NUM 10

float Get_Cycle_T(u8);
void TDT_Cycle_Time_Init(void);

#endif

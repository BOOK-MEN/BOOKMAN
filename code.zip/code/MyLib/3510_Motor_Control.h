#ifndef _3510Motor_H
#define _3510Motor_H

#include "board.h"

#define Singel_Circle	8192*19
#define Target_Location 10000*19

void Motor3510_Inner_PIDControl(float* setValue, float* fbValue, float* result, float T);
void Motor3510_Outer_PIDControl(float* setValue, float* fbValue, float* result, float T);
void Motor3510_Control(float T);



#endif

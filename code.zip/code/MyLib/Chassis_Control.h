#ifndef _CHASSIS_CONTROL_H
#define _CHASSIS_CONTROL_H

#include "board.h"

#define WHEEL_NUMBER	4

#define FB_MAXSPEED		5000/660.0f
#define LR_MAXSPEED		5000/660.0f
#define ROT_MAXASPEED	5000/660.0f

void Chassis_PidControl(vec4f* setValue, vec4f* fbValue, vec4f* result, float T, u8 dimConVar);
void Chassis_Control(float T);


#endif

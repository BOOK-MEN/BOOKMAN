#include "dbus.h"

rc NDJ6;
int16_t subus_decode_keboard_buffer[16];  //keyboard data�����ϵ�����
unsigned char sbus_rx_buffer[18];

void TDT_Dbus_Configuration(void)
{		
		USART_InitTypeDef USART_InitStructure;
	  GPIO_InitTypeDef  GPIO_InitStructure;
    NVIC_InitTypeDef  NVIC_InitStructure;
    DMA_InitTypeDef   DMA_InitStructure;
	
		RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA | RCC_AHB1Periph_DMA1,ENABLE);
		RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART2,ENABLE);
		
		GPIO_PinAFConfig(GPIOA,GPIO_PinSource3 ,GPIO_AF_USART3);
	
		GPIO_InitStructure.GPIO_Pin = GPIO_Pin_3;
		GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;
		GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
		GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;
		GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_NOPULL;
		GPIO_Init(GPIOA,&GPIO_InitStructure);
    
		USART_DeInit(USART2);
		USART_InitStructure.USART_BaudRate = 100000;
		USART_InitStructure.USART_WordLength = USART_WordLength_8b;
		USART_InitStructure.USART_StopBits = USART_StopBits_1;
		USART_InitStructure.USART_Parity = USART_Parity_No;
		USART_InitStructure.USART_Mode = USART_Mode_Tx|USART_Mode_Rx;
		USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
		USART_Init(USART2,&USART_InitStructure);			
		USART_Cmd(USART2,ENABLE);
				
		USART_ITConfig(USART2,USART_IT_IDLE,ENABLE);
		   
    USART_DMACmd(USART2,USART_DMAReq_Rx,ENABLE);
 
    NVIC_InitStructure.NVIC_IRQChannel = USART2_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 3;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStructure);
 
    DMA_DeInit(DMA1_Stream5);
    DMA_InitStructure.DMA_Channel= DMA_Channel_4;
    DMA_InitStructure.DMA_PeripheralBaseAddr = (uint32_t)&(USART2->DR);
    DMA_InitStructure.DMA_Memory0BaseAddr = (uint32_t)sbus_rx_buffer;
    DMA_InitStructure.DMA_DIR = DMA_DIR_PeripheralToMemory;
    DMA_InitStructure.DMA_BufferSize = 18;
    DMA_InitStructure.DMA_PeripheralInc = DMA_PeripheralInc_Disable;
    DMA_InitStructure.DMA_MemoryInc = DMA_MemoryInc_Enable;
    DMA_InitStructure.DMA_PeripheralDataSize = DMA_PeripheralDataSize_Byte;
    DMA_InitStructure.DMA_MemoryDataSize = DMA_MemoryDataSize_Byte;
    DMA_InitStructure.DMA_Mode = DMA_Mode_Circular;
    DMA_InitStructure.DMA_Priority = DMA_Priority_High;
    DMA_InitStructure.DMA_FIFOMode = DMA_FIFOMode_Disable;
    DMA_InitStructure.DMA_FIFOThreshold = DMA_FIFOThreshold_1QuarterFull;
    DMA_InitStructure.DMA_MemoryBurst = DMA_Mode_Normal;
    DMA_InitStructure.DMA_PeripheralBurst = DMA_PeripheralBurst_Single;
    DMA_Init(DMA1_Stream5,&DMA_InitStructure);

    DMA_Cmd(DMA1_Stream5,ENABLE);
}


void USART2_IRQHandler(void)
{
	u16 i;
	int16_t sbus_decode_buffer[4];
	int keboard_buffer_flag=0;
	
	if(USART_GetITStatus(USART2, USART_IT_IDLE) != RESET)
	{
		DMA_Cmd(DMA1_Stream5,DISABLE);
		
		i = USART2->SR;  
		i = USART2->DR; 
			
		//��ҡ�˺���   ��Χ+-660
		sbus_decode_buffer[0] = (sbus_rx_buffer[0]| (sbus_rx_buffer[1] << 8)) & 0x07ff; //!< Channel 0
		NDJ6.ch[0] = my_deathzoom(sbus_decode_buffer[0]-1024, 10);
		//��ҡ������   ��Χ+-660
		sbus_decode_buffer[1] = ((sbus_rx_buffer[1] >> 3) | (sbus_rx_buffer[2] << 5)) & 0x07ff; //!< Channel 1
		NDJ6.ch[1] = my_deathzoom(sbus_decode_buffer[1]-1024, 10);
		//��ҡ�˺���   ��Χ+-660
		sbus_decode_buffer[2]= ((sbus_rx_buffer[2] >> 6) | (sbus_rx_buffer[3] << 2) | (sbus_rx_buffer[4] << 10)) & 0x07ff; //!< Channel 2
		NDJ6.ch[2] = my_deathzoom(sbus_decode_buffer[2]-1024, 10);
		//��ҡ������   ��Χ+-660
		sbus_decode_buffer[3] = ((sbus_rx_buffer[4] >> 1) | (sbus_rx_buffer[5] << 7)) & 0x07ff; //!< Channel 3
		NDJ6.ch[3] = my_deathzoom(sbus_decode_buffer[3]-1024, 10);
		//��߿���  132 ������
		NDJ6.ch[4] = ((sbus_rx_buffer[5] >> 4)& 0x000C) >> 2; //!< Switch left
		//�ұ߿���  132 ������
		NDJ6.ch[5] = ((sbus_rx_buffer[5] >> 4)& 0x0003); //!< Switch right9 / 9 

    NDJ6.ch[6] = 	((sbus_rx_buffer[6]) | (sbus_rx_buffer[7] << 8)); //����ƶ�x
		NDJ6.ch[7] = 	-((sbus_rx_buffer[8]) | (sbus_rx_buffer[9] << 8)); //����ƶ�y
		NDJ6.ch[8] = sbus_rx_buffer[12]; //������
		NDJ6.ch[9] = sbus_rx_buffer[13]; //����Ҽ�	
		NDJ6.ch[10] = sbus_rx_buffer[14] | (sbus_rx_buffer[15] << 8); //W(1)S(2)A(4)D(8) QE shift(16) ctr(32) 
		
	//	subus_decode_keboard_buffer[0] ~ subus_decode_keboard_buffer[15]���ζ�ӦW A S D / Shift Ctrl Q E / R F G Z / X C V B
	
		for(keboard_buffer_flag=0;keboard_buffer_flag<=15;keboard_buffer_flag++)
		{
			subus_decode_keboard_buffer[keboard_buffer_flag]= (int)((NDJ6.ch[10]>>keboard_buffer_flag)&0x01);
		}	

		DMA1_Stream5->NDTR = 18;
		USART_ClearITPendingBit(USART2, USART_IT_IDLE);
		DMA_Cmd(DMA1_Stream5,ENABLE);
	}
}

#ifndef __CAN2_H__
#define __CAN2_H__

#include "board.h"

typedef struct _can2_feedback
{
	int16_t Chassis_Mortor[4];
}can2_feedback;

extern can2_feedback can2Feedback;

void TDT_CAN2_Configuration(void);

void Chassis_OutUpdate(vec4f value);


#endif 

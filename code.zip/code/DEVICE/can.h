#ifndef __CAN1_H__
#define __CAN1_H__

#include "board.h"
typedef struct _can1_feedback
{
	int16_t screwt[4];
	int16_t screwl[1];
	//int16_t	motorSpeed;
	//double motorPosition;
	double screwtPosition[4];
	double screwlPosition[1];
}can1_feedback;

extern can1_feedback can1Feedback;

void TDT_CAN1_Configuration(void);
void TDT_screwl_OutUpdate(vec4f value);
void TDT_screwt_OutUpdate(vec4f value);
//void TDT_screwl_OutUpdate(vec4f value);
#endif 


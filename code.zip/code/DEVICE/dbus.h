#ifndef _Dbus_H
#define _Dbus_H

#include "board.h"

typedef struct _rc{
					int16_t ch[11];
          }rc;

extern rc NDJ6;
extern int16_t subus_decode_keboard_buffer[16];  //keyboard data
void TDT_Dbus_Configuration(void);

#endif /*_Dbus_H*/

#ifndef __BOARD_H__
#define __BOARD_H__

#include "stm32f4xx.h"
#include "stm32f4xx_conf.h"

/***************Ӳ���жϷ���******************/
#define NVIC_GROUP   NVIC_PriorityGroup_3

#include "stdint.h"
#include "TDT_infantry.h"
#include "schedule.h"
#include "can.h"
#include "can2.h"
#include "mymath.h"
#include "parameter.h"
#include "time.h"
#include "softiic.h"
#include "Voice_Distance.h"
#include "usart1.h"
#include "dbus.h"
#include "Chassis_Control.h"




/***************I2C GPIO����******************/
#define RCC_I2C1	     RCC_AHB1Periph_GPIOB
#define I2C1_PORT      GPIOB
#define I2C1_Pin_SCL   GPIO_Pin_0
#define I2C1_Pin_SDA   GPIO_Pin_1

#define RCC_I2C2	     RCC_AHB1Periph_GPIOC
#define I2C2_PORT      GPIOC
#define I2C2_Pin_SCL   GPIO_Pin_0
#define I2C2_Pin_SDA   GPIO_Pin_1



/***************LED GPIO����******************/


void TDT_SysTick_Configuration(void);
uint32_t GetSysTime_us(void);
void DelayUs(uint32_t us);
void DelayMs(uint32_t ms);
void TDT_Board_ALL_Init(void);

extern volatile uint32_t sysTickUptime;

typedef struct _robotFlag
				{
					u16 bulletFired;
					float outOfControlTime;
					u8 outOfControl;
					int scanDir;
				} robotFlag;
				
extern robotFlag baseFlag;

#endif /* __BOARD_H__ */


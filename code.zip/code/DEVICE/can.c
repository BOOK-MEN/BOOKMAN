#include "can.h"

/*----CAN1_TX-----PA12----*/
/*----CAN1_RX-----PA11----*/
can1_feedback can1Feedback;
void TDT_CAN1_Configuration(void)
{
    CAN_InitTypeDef        can;
    CAN_FilterInitTypeDef  can_filter;
    GPIO_InitTypeDef       gpio;
    NVIC_InitTypeDef       nvic;

    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA, ENABLE);
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_CAN1, ENABLE);

    GPIO_PinAFConfig(GPIOA, GPIO_PinSource12, GPIO_AF_CAN1);
    GPIO_PinAFConfig(GPIOA, GPIO_PinSource11, GPIO_AF_CAN1);

    gpio.GPIO_Pin = GPIO_Pin_12 | GPIO_Pin_11;
    gpio.GPIO_Mode = GPIO_Mode_AF;
    GPIO_Init(GPIOA, &gpio);
    
    nvic.NVIC_IRQChannel = CAN1_RX0_IRQn;
    nvic.NVIC_IRQChannelPreemptionPriority = 2;
    nvic.NVIC_IRQChannelSubPriority = 1;
    nvic.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&nvic);
    
    nvic.NVIC_IRQChannel = CAN1_TX_IRQn;
    nvic.NVIC_IRQChannelPreemptionPriority = 1;
    nvic.NVIC_IRQChannelSubPriority = 1;
    nvic.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&nvic);    
    
    CAN_DeInit(CAN1);
    CAN_StructInit(&can);
    
    can.CAN_TTCM = DISABLE;
    can.CAN_ABOM = DISABLE;
    can.CAN_AWUM = DISABLE;
    can.CAN_NART = DISABLE;
    can.CAN_RFLM = DISABLE;
    can.CAN_TXFP = ENABLE;
    can.CAN_Mode = CAN_Mode_Normal;
    can.CAN_SJW  = CAN_SJW_1tq;
    can.CAN_BS1 = CAN_BS1_9tq;
    can.CAN_BS2 = CAN_BS2_4tq;
    can.CAN_Prescaler = 3;   //CAN BaudRate 42/(1+9+4)/3=1Mbps
    CAN_Init(CAN1, &can);

		can_filter.CAN_FilterNumber=0;		
		can_filter.CAN_FilterMode=CAN_FilterMode_IdMask;
		can_filter.CAN_FilterScale=CAN_FilterScale_32bit;
		can_filter.CAN_FilterIdHigh=0x0000;
		can_filter.CAN_FilterIdLow=0x0000;
		can_filter.CAN_FilterMaskIdHigh=0x0000;
		can_filter.CAN_FilterMaskIdLow=0x0000;
		can_filter.CAN_FilterFIFOAssignment=0;
		can_filter.CAN_FilterActivation=ENABLE;
		CAN_FilterInit(&can_filter);
			
		CAN_ITConfig(CAN1,CAN_IT_FMP0,ENABLE);
		CAN_ITConfig(CAN1,CAN_IT_TME,ENABLE); 
}

void CAN1_RX0_IRQHandler(void)
{
		CanRxMsg Can1RxMsg;
	
    if (CAN_GetITStatus(CAN1,CAN_IT_FMP0)!= RESET)
	  {
			CAN_ClearITPendingBit(CAN1, CAN_IT_FMP0);
			CAN_Receive(CAN1, CAN_FIFO0, &Can1RxMsg);
    }	
	  switch(Can1RxMsg.StdId)
		{
				case 0x201:
						can1Feedback.screwt[0] = (int16_t)((Can1RxMsg.Data[2]<<8)|(Can1RxMsg.Data[3]));
				    can1Feedback.screwtPosition[0] += 0.000222f * can1Feedback.screwt[0];
						break;
				case 0x202:
						can1Feedback.screwt[1] = (int16_t)((Can1RxMsg.Data[2]<<8)|(Can1RxMsg.Data[3]));
				    can1Feedback.screwtPosition[1] += 0.000222f * can1Feedback.screwt[1];
						break;
				case 0x203:
						can1Feedback.screwt[2]=(int16_t)((Can1RxMsg.Data[2]<<8)|(Can1RxMsg.Data[3]));
				    can1Feedback.screwtPosition[2] += 0.000222f * can1Feedback.screwt[2];
						break;
				case 0x204:
						can1Feedback.screwt[3]=(int16_t)((Can1RxMsg.Data[2]<<8)|(Can1RxMsg.Data[3]));
			    	can1Feedback.screwtPosition[3] += 0.000222f * can1Feedback.screwt[3];
						break;		
        case 0x205:		
					  can1Feedback.screwl[0]=(int16_t)((Can1RxMsg.Data[2]<<8)|(Can1RxMsg.Data[3]));
				    can1Feedback.screwlPosition[0] += 0.000222f * can1Feedback.screwl[0];
            break;					
				default:break;						
		} 		
}

void CAN1_TX_IRQHandler(void)
{
  if (CAN_GetITStatus(CAN1,CAN_IT_TME)!= RESET) 
	{
	   CAN_ClearITPendingBit(CAN1,CAN_IT_TME);
  }
}

void TDT_screwt_OutUpdate(vec4f value)
{
		CanTxMsg Can1TxMsg;
	 
	
		Can1TxMsg.IDE = 0;             //��׼֡
		Can1TxMsg.RTR = 0;             //����֡
		Can1TxMsg.DLC = 8;             //֡����

		Can1TxMsg.StdId =  0x200;      //ID:0x200

			/*������ҿ��ؾ�λ�����Ϸ�λ�ã���������ȫ�ֶ�״̬*/
		if(NDJ6.ch[4]==1 && NDJ6.ch[5]==1)
		{
		Can1TxMsg.Data[0] = (u8)((int16_t)value.data[0]>>8);
		Can1TxMsg.Data[1] = (u8)(value.data[0]);
		Can1TxMsg.Data[2] = (u8)((int16_t)value.data[1]>>8);
		Can1TxMsg.Data[3] = (u8)(value.data[1]);
		Can1TxMsg.Data[4] = (u8)((int16_t)value.data[2]>>8);
		Can1TxMsg.Data[5] = (u8)(value.data[2]);
		Can1TxMsg.Data[6] = (u8)((int16_t)value.data[3]>>8);
		Can1TxMsg.Data[7] = (u8)(value.data[3]);
		}

		/*������ҿ��ؾ���λ�����Ϸ�ʱ�����鲿�ֲ�ִ���κι���*/
		else
		{
		Can1TxMsg.Data[0] = 0;
		Can1TxMsg.Data[1] = 0;
		Can1TxMsg.Data[2] = 0;
		Can1TxMsg.Data[3] = 0;
		Can1TxMsg.Data[4] = 0;
		Can1TxMsg.Data[5] = 0;
		Can1TxMsg.Data[6] = 0;
		Can1TxMsg.Data[7] = 0;
		}
		CAN_Transmit(CAN1,&Can1TxMsg);
    DelayUs(100);
}


void TDT_screwl_OutUpdate(vec4f value)
{
   CanTxMsg Can1TxMsg;
	 
	
		Can1TxMsg.IDE = 0;             //��׼֡
		Can1TxMsg.RTR = 0;             //����֡
		Can1TxMsg.DLC = 8;             //֡����

   	//float outPut = LIMIT(value, -MAXSET3510, MAXSET3510);
	
	  Can1TxMsg.StdId =  0x1FF;      //ID:0x1FF
	
	  
			/*������ҿ��ؾ�λ�����Ϸ�λ�ã���������ȫ�ֶ�״̬*/
			 if(NDJ6.ch[4]==1 && NDJ6.ch[5]==1)
      {
	    Can1TxMsg.Data[0] = (u8)((int16_t)value.data[0]>>8);
			Can1TxMsg.Data[1] = (u8)(value.data[0]);
			Can1TxMsg.Data[2] = 0;
			Can1TxMsg.Data[3] = 0;
			Can1TxMsg.Data[4] = 0;
			Can1TxMsg.Data[5] = 0;
			Can1TxMsg.Data[6] = 0;
			Can1TxMsg.Data[7] = 0;
			 }
	
		  /*������ҿ��ؾ���λ�����Ϸ�ʱ�����鲿�ֲ�ִ���κι���*/
	    else
			{
		  Can1TxMsg.Data[0] = 0;
			Can1TxMsg.Data[1] = 0;
			}
	
	    CAN_Transmit(CAN1,&Can1TxMsg);
      DelayUs(100);


}



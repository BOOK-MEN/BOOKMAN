#ifndef _SOFT_I2C_H__
#define _SOFT_I2C_H__

#include "board.h"

/*I2C2�궨��*/
#define SCL1_H         I2C1_PORT->BSRRL = I2C1_Pin_SCL
#define SCL1_L         I2C1_PORT->BSRRH = I2C1_Pin_SCL
#define SDA1_H         I2C1_PORT->BSRRL = I2C1_Pin_SDA
#define SDA1_L         I2C1_PORT->BSRRH = I2C1_Pin_SDA
#define SDA1_read      I2C1_PORT->IDR  & I2C1_Pin_SDA

/*I2C2�궨��*/
#define SCL2_H         I2C2_PORT->BSRRL = I2C2_Pin_SCL
#define SCL2_L         I2C2_PORT->BSRRH = I2C2_Pin_SCL
#define SDA2_H         I2C2_PORT->BSRRL = I2C2_Pin_SDA
#define SDA2_L         I2C2_PORT->BSRRH = I2C2_Pin_SDA
#define SDA2_read      I2C2_PORT->IDR  & I2C2_Pin_SDA

/*I2C1��������*/
void I2C1_Soft_Init(void);
void I2C1_Soft_Delay(void);
int I2C1_Soft_Start(void);
void I2C1_Soft_Stop(void);
void I2C1_Soft_Ack(void);
void I2C1_Soft_NoAck(void);
int I2C1_Soft_WaitAck(void); 	 //����:=1��ACK,=0��ACK
void I2C1_Soft_SendByte(u8 SendByte);
u8 I2C1_Soft_ReadByte(void);
int I2C1_Soft_Single_Write(u8 SlaveAddress,u8 REG_Address,u8 REG_data);
int I2C1_Soft_Single_Read(u8 SlaveAddress,u8 REG_Address);
int I2C1_Soft_Mult_Read(u8 SlaveAddress,u8 REG_Address,u8 * ptChar,u8 size);


/*I2C2��������*/
void I2C2_Soft_Init(void);
void I2C2_Soft_Delay(void);
int I2C2_Soft_Start(void);
void I2C2_Soft_Stop(void);
void I2C2_Soft_Ack(void);
void I2C2_Soft_NoAck(void);
int I2C2_Soft_WaitAck(void); 	 //����:=1��ACK,=0��ACK
void I2C2_Soft_SendByte(u8 SendByte);
u8 I2C2_Soft_ReadByte(void);
int I2C2_Soft_Single_Write(u8 SlaveAddress,u8 REG_Address,u8 REG_data);
int I2C2_Soft_Single_Read(u8 SlaveAddress,u8 REG_Address);
int I2C2_Soft_Mult_Read(u8 SlaveAddress,u8 REG_Address,u8 * ptChar,u8 size);


extern u8 I2C1_FastMode;
extern u8 I2C2_FastMode;

#endif

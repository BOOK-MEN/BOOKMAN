#ifndef _VOICE_DISTANCE_H
#define _VOICE_DISTANCE_H

#include "board.h"

#define HC_SR04_Port     GPIOB
#define HCSR04_CLK      RCC_AHB1Periph_GPIOB
#define Trig     				GPIO_Pin_5
#define Echo     				GPIO_Pin_6
 

#define TRIG_Send_H  GPIO_SetBits(GPIOB,GPIO_Pin_5)
#define TRIG_Send_L  GPIO_ResetBits(GPIOB,GPIO_Pin_5)
#define ECHO_Reci		 GPIO_ReadOutputDataBit(GPIOB,GPIO_Pin_6)

void Timer_Config(void);
void HS_GPIO_Config(void);
int UltraSonic(void);



#endif

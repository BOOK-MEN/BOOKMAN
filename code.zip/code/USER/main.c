#include "stm32f4xx.h"
#include "board.h"
#include "schedule.h"

int main(void)
{
	TDT_Board_ALL_Init();

	while(1)
	{				
		DelayMs(100);
	}
}

#include "parameter.h"


void TDT_Get_PIDparameters(pid* pidStruct, u8 pidIndex)
{
	switch(pidIndex)
	{
		case Chassis_Move:
			pidStruct->kp = 0.6f;
			pidStruct->ki = 0.0f;
			pidStruct->integralErrorMax = 0;
			pidStruct->integralError = 0;
			break;	
		
		default:
			break;
	}
}

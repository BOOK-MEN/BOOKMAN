#ifndef _PARAMETER_H
#define	_PARAMETER_H

#include "board.h"

#define Chassis_Move 		0




void TDT_Get_PIDparameters(pid* pidStruct, u8 pidIndex);

#endif
